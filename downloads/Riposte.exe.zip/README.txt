Hi there!

Please enjoy our game!

Please note you may have to restart upon finishing a game
, as there are a few bugs with the menu:)

Right click to move and use Q,W,E,R to cast your abilities!

Q: Blink
W: Shoot
E: Melee
R: Deflect

Happy Hunting!